package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Where;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Where(clause = "is_active = true")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String surname;

    @Column(name = "email")
    private String email;

    private String address;

    @Column(name = "password")
    private String password;

    @Builder.Default
    @Column(name = "is_active")
    private Boolean isActive = true;

    @OneToOne(mappedBy = "user")
    private Basket basket;

//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "role_id")
//    private Role role;


}



//    @Column(name = "username")
//    private String username;
//    @OneToOne(cascade = CascadeType.ALL)
//    @JoinColumn(name = "basket_id",referencedColumnName = "id")
//    private Basket basket;
//
//    @OneToMany(mappedBy = "user")
//    private Set<Favorite> favorites = new HashSet<>();