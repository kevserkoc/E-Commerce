package com.example.demo.service;

import com.example.demo.dto.request.OrderRequest;
import com.example.demo.dto.response.BasketResponse;
import com.example.demo.dto.response.ProductResponse;
import com.example.demo.entity.Basket;
import com.example.demo.entity.Product;
import com.example.demo.entity.User;
import com.example.demo.repository.BasketRepository;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    private final BasketRepository basketRepository;
    private final BasketService basketService;

    public OrderService(OrderRepository orderRepository, UserRepository userRepository, ProductRepository productRepository, BasketRepository basketRepository, BasketService basketService) {
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
        this.productRepository = productRepository;
        this.basketRepository = basketRepository;
        this.basketService = basketService;
    }

    public void saveOrder(OrderRequest orderRequest){
        User user = userRepository.findById(orderRequest.getUser_id()).get();
        Basket basket = basketRepository.findByUserId(user.getId());
        List<Product> productList = new ArrayList<>();

    }


    private BasketResponse mapToBasketResponse(Basket basket){
        BasketResponse basketResponse = new BasketResponse();
        basketResponse.setId(basket.getId());
        basketResponse.setQuantity(basket.getQuantity());
        basketResponse.setUserId(basket.getUser().getId());
        basketResponse.setTotalAmount(basketService.calculateTotalAmount(basket.getId()));
        basketResponse.setProductResponse(mapToProduct(basket.getProducts()));
        return basketResponse;
    }

    private List<ProductResponse> mapToProduct(List<Product> product){
        List<ProductResponse> productResponse = new ArrayList<>();
        for (Product product1 : product){
            ProductResponse productResponse1 = new ProductResponse();
            productResponse1.setCategoryId(product1.getId());
            productResponse1.setName(product1.getName());
            productResponse1.setStock(product1.getStock());
            productResponse1.setDescription(product1.getDescription());
            productResponse1.setImageUrl(product1.getImageUrl());
            productResponse.add(productResponse1);
        }
        return productResponse;
    }
}
