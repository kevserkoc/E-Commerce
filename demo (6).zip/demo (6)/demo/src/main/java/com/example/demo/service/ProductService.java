package com.example.demo.service;

import com.example.demo.dto.request.ProductRequest;
import com.example.demo.dto.request.UserRequest;
import com.example.demo.dto.response.BasketResponse;
import com.example.demo.dto.response.ProductResponse;
import com.example.demo.dto.response.UserResponse;
import com.example.demo.entity.Basket;
import com.example.demo.entity.Category;
import com.example.demo.entity.Product;
import com.example.demo.entity.User;
import com.example.demo.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;
    private final CategoryService categoryService;


    public ProductResponse createProduct(ProductRequest request) {
        Product product = getProducts(request);
        Product savedProduct = productRepository.save(product);
        return getProductResponse(product);
    }

    public List<ProductResponse> getAllProducts(){
        return productRepository.findAll()
                .stream()
                .map(this::getProductResponse)
                .toList();
    }
    public List<ProductResponse> getProductsByCategoryId(Long categoryId){
        Category category = categoryService.getCategoryById(categoryId); //exception
        List<Product> products = productRepository.findAllByCategory_Id(category.getId());
        return  products.stream()
                .map(this::getProductResponse)
                .toList();
    }
public List<ProductResponse> searchProductsByName(String name){
        List<Product> products = productRepository.findByNameWithQuery(name);
        if (products.isEmpty()){
            throw new RuntimeException();
        }
        return products.stream().map(this::getProductResponse)
                .toList();
}

    private  ProductResponse getProductResponse(Product product) {

        return ProductResponse.builder()
                .price(product.getPrice())
                .name(product.getName())
                .stock(product.getStock())
                .imageUrl(product.getImageUrl())
                .description(product.getDescription())
                .categoryId(product.getCategory().getId())
                .build();
    }

    private Product getProducts(ProductRequest request) {
        Category category = categoryService.getCategory(request.getCategoryId());
//        Category categoryById = categoryService.getCategoryById(request.getCategoryId());
       return Product.builder().name(request.getName())
                .price(request.getPrice())
                .description(request.getDescription())
                .imageUrl(request.getImageUrl())
                .category(category)
                .build();
    }

    public Product getProduct(Long productId) {

        return productRepository.findById(productId).orElseThrow();
    }

    public Optional<Product> findById(Long productId) {
       return productRepository.findById(productId);
    }

//    public List<Product> findAll(List<Product> products) {
//        return productRepository.findAll();
//    }
public List<Product> findAll(List<Long> productIds) {
    return productRepository.findAllById(productIds);

}


    public List<ProductResponse> getAllProductResponse(List<Product> products) {

        return products.stream().map(this::getProductResponse).toList();
    }

    public Product update(Product product) {
       return productRepository.save(product);
    }
}
