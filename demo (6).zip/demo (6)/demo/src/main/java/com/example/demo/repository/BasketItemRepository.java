package com.example.demo.repository;

import com.example.demo.entity.Basket;
import com.example.demo.entity.BasketItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BasketItemRepository extends JpaRepository<BasketItem, Long> {
//    @Query("from BasketItem b where b.basket.id = :basketId")
//    List<BasketItem> findBasketItemsByBasketId(Long basketId);

}
