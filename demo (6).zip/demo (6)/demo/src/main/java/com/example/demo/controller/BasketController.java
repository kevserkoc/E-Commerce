package com.example.demo.controller;

import com.example.demo.dto.request.BasketRequest;
import com.example.demo.dto.request.ProductBasketRequest;
import com.example.demo.dto.response.BasketResponse;
import com.example.demo.entity.Basket;
import com.example.demo.service.BasketService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequestMapping("api/baskets")
@RequiredArgsConstructor
@RestController
public class BasketController {

    private final BasketService basketService;


    @PostMapping("/addProductToBasket")
    public ResponseEntity<Basket> addProductToBasket(
            @RequestParam("basketId") Long basketId,
            @RequestParam("productId") Long productId
    ) {
        Basket basket = basketService.addProductToBasket(basketId, productId);
        return ResponseEntity.ok(basket);
    }
    @GetMapping("/getBasket")
    public ResponseEntity<BasketResponse> getBasket(@RequestParam("basketId") Long basketId,
                                                    @RequestParam("userId") Long userId) {
        BasketResponse basket = basketService.getBasketProducts(basketId,userId);
        return ResponseEntity.ok(basket);
    }
    @PostMapping
    ResponseEntity<BasketResponse> createBasket(@RequestBody BasketRequest request){
        BasketResponse basket = basketService.createBasket(request);
        return ResponseEntity.ok(basket);
    }
    @PutMapping
    public ResponseEntity<BasketResponse> addAnd(@RequestBody ProductBasketRequest request) {
        return ResponseEntity.ok(basketService.addAndUpdateProductToBasket(request));
    }
}
