package com.example.demo.service;

import com.example.demo.dto.request.UserRequest;
import com.example.demo.dto.response.UserResponse;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;

    public UserResponse createUser(UserRequest request) {
        User user = userRepository.save(getUser(request));
        return getUserResponse(user);
    }

    private UserResponse getUserResponse(User user) {
        return UserResponse.builder().name(user.getName())
                .surname(user.getSurname())
                .address(user.getAddress())
                .email(user.getEmail())
                .build();
    }

    private User getUser(UserRequest request) {
        return User.builder().name(request.getName())
                .password(request.getPassword())
                .surname(request.getSurname())
                .address(request.getAddress())
                .email(request.getEmail())
                .build();
    }

    public User getUserById(Long userId) {
        return userRepository.findById(userId).orElseThrow();
    }
}
