package com.example.demo.service;

import com.example.demo.dto.request.CategoryRequest;
import com.example.demo.dto.request.CategoryUpdateRequest;
import com.example.demo.dto.response.CategoryResponse;
import com.example.demo.dto.response.ProductResponse;
import com.example.demo.entity.Category;
import com.example.demo.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CategoryService {
    private final CategoryRepository categoryRepository;

    public List<CategoryResponse> getAllCategories(){
        return categoryRepository.findAll()
                .stream()
                .map(this::getCategoryResponse)
                .toList();
    }
    public CategoryResponse createCategory(CategoryRequest request){
        Category build = Category.builder().name(request.getName()).build();
        Category savedCategory = categoryRepository.save(build);
        return getCategoryResponse(savedCategory);
    }
    public void deleteCategory(Long id){
        Category category = categoryRepository.findById(id).orElseThrow();
        category.setIsActive(false);
        categoryRepository.save(category);
    }
    public CategoryResponse updateCategory(CategoryUpdateRequest request){
        var optionalCategory = categoryRepository.findById(request.getId());
        if (optionalCategory.isPresent()){
            var category = optionalCategory.get();
            category.setName(request.getName());
            category = categoryRepository.save(category);
            return getCategoryResponse(category);
        }
            throw new RuntimeException();
    }


    private CategoryResponse getCategoryResponse(Category savedCategory) {
        return CategoryResponse.builder()
                .id(savedCategory.getId())
                .name(savedCategory.getName())
                .build();
    }


    public Category getCategoryById(Long categoryId) {
        return categoryRepository.findById(categoryId).orElseThrow();
    }

    public Category getCategory(Long categoryId) {
        return categoryRepository.findById(categoryId).orElse(null);
    }
}
