package com.example.demo.dto.request;

import lombok.Data;

@Data
public class OrderItemRequest {

    private Long id;
    private Long product_id;
}
