package com.example.demo.dto.request;

import lombok.Data;

import java.util.List;

@Data
public class OrderRequest {

    private Long user_id;

    private List<ProductRequest> productRequests;

    private int totalPrice;


}
