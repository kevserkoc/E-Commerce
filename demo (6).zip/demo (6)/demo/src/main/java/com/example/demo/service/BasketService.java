package com.example.demo.service;

import com.example.demo.dto.request.BasketCreateRequest;
import com.example.demo.dto.request.BasketRequest;
import com.example.demo.dto.request.ProductBasketRequest;
import com.example.demo.dto.response.BasketResponse;
import com.example.demo.dto.response.ProductResponse;
import com.example.demo.entity.Basket;
import com.example.demo.entity.Product;
import com.example.demo.entity.User;
import com.example.demo.repository.BasketRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class BasketService {
    private final BasketRepository basketRepository;
    private final UserService userService;
    private final ProductService productService;

    public BasketService(BasketRepository basketRepository, UserService userService, ProductService productService) {
        this.basketRepository = basketRepository;
        this.userService = userService;
        this.productService = productService;
    }

    @Transactional
    public BasketResponse createBasket(BasketRequest request) {
        User userById = userService.getUserById(request.getUserId());
        List<Long> productIds = request.getProductsAndQuantities().stream()
                .map(BasketCreateRequest::getProductId).toList();

        List<Product> products = productService.findAll(productIds);
        List<ProductResponse> allProductResponse = productService.getAllProductResponse(products);
    return new BasketResponse();
    }

//        List<ProductResponse> allProductsResponse = productService.getAllProductResponse(products);
//                new ArrayList<>();
//        List<Product> list = productIds.stream().map(productId -> {
//            Product product=  productService.findById(productId).get();
//            products.add(product);
//            return product;
//        }).toList();


//    List<Product> products = basket.getProducts();
//    List<ProductResponse> allProductResponse = productService.getAllProductResponse(products);
//
//    User user = userService.getUserById(userId);
//
//        return BasketResponse.builder()
//                .id(basket.getId())
//            .userId(user.getId())
//            .productResponse(allProductResponse)
//                .totalAmount(calculateTotalAmount(basket.getId()))
//            .build();

//    private BasketResponse getBuild(Basket savedBasket) {
//        List<ProductResponse> allProductResponse = productService.getAllProductResponse(savedBasket.getProducts());
//        return BasketResponse.builder().id(savedBasket.getId())
//                .userId(savedBasket.getUser().getId())
//                .productResponse(allProductResponse)
//                .build();
//    }

    public BasketResponse addAndUpdateProductToBasket(ProductBasketRequest request) {
        Product product = productService.getProduct(request.getProductId());
        product.setQuantity(null);
        this.productService.update(product);
        product.setQuantity(request.getQuantity());
        Product updatedProduct = productService.update(product);
        Basket basket = basketRepository.findById(request.getBasketId()).orElseThrow();
         basket.getProducts().add(updatedProduct); //set?
        basketRepository.save(basket);
//        return getBuild(basket);
        Basket savedBasket = basketRepository.save(basket);
        List<ProductResponse> allProductResponse = productService.getAllProductResponse(savedBasket.getProducts());
        return BasketResponse.builder().id(savedBasket.getId())
                .userId(savedBasket.getUser().getId())
                .quantity(savedBasket.getQuantity())
                .productResponse(allProductResponse)
                .totalAmount(calculateTotalAmount(savedBasket.getId()))
                .build();
    }

    public void deleteProducts(){

    }

    public BasketResponse getBasketProducts(Long basketId, Long userId) {
        Basket basket = basketRepository.findById(basketId).orElse(null);

        if (basket == null) {
            throw new RuntimeException("Basket not found");
        }

        List<Product> products = basket.getProducts();
        List<ProductResponse> allProductResponse = productService.getAllProductResponse(products);

        User user = userService.getUserById(userId);

        return BasketResponse.builder()
                .id(basket.getId())
                .userId(user.getId())
                .productResponse(allProductResponse)
                .quantity(basket.getQuantity())
                .totalAmount(calculateTotalAmount(basket.getId()))
                .build();
    }


//    private Double calculateTotalAmount(Long basketId) {
//        Basket basket = basketRepository.findById(basketId).orElseThrow();
//
//        double totalAmount = basket.getProducts().stream()
//                .mapToDouble(product -> product.getPrice() * product.getQuantity())
//                .sum();
//
//        return totalAmount;
//    }

    public Double calculateTotalAmount(Long basketId) {

        Basket basket = basketRepository.findById(basketId).orElseThrow();
        double sum = basket.getProducts().stream().mapToDouble(Product::getPrice).sum();
        return basket.getQuantity() * sum;
    }


//    private Basket getBasketEntity(BasketRequest request) {
//        User userById = userService.getUserById(request.getUserId());
//        List<Product> products = productService.findAll(request.getProducts());
//      return  Basket.builder().user(userById)
//                .quantity(request.getQuantity())
//                .products(products)
//                .build();
//    }

    public Basket getBasket(Long basketId) {
        return basketRepository.findById(basketId).orElse(null);
    }

    public Basket addProductToBasket(Long basketId, Long productId) {
        Basket basket = basketRepository.findById(basketId).orElse(null);
        Product product = productService.findById(productId).orElse(null);

        if (basket != null && product != null) {
            basket.getProducts().add(product);
            basketRepository.save(basket);
        }

        return basket;
    }


}
