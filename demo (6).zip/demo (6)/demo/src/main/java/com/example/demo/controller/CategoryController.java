package com.example.demo.controller;

import com.example.demo.dto.request.CategoryRequest;
import com.example.demo.dto.request.CategoryUpdateRequest;
import com.example.demo.dto.request.ProductRequest;
import com.example.demo.dto.response.CategoryResponse;
import com.example.demo.dto.response.ProductResponse;
import com.example.demo.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/categories")
@RequiredArgsConstructor
public class CategoryController {
    private final CategoryService categoryService;

    @GetMapping
    ResponseEntity<List<CategoryResponse>> getAllProduct(){
        List<CategoryResponse> allCategories = categoryService.getAllCategories();
        return ResponseEntity.ok(allCategories);
    }
    @PostMapping
    ResponseEntity<CategoryResponse> createCategory(@RequestBody CategoryRequest request){
        CategoryResponse category = categoryService.createCategory(request);
      return ResponseEntity.ok(category);
    }
    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteCategory(@PathVariable Long id){
        categoryService.deleteCategory(id);
        return ResponseEntity.ok("Category is deleted." + id);
    }
    @PutMapping
    public ResponseEntity<CategoryResponse> updateCategory(@RequestBody CategoryUpdateRequest request) {
        return ResponseEntity.ok(categoryService.updateCategory(request));
    }


}
