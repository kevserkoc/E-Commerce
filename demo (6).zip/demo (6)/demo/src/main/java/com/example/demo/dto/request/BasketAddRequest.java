package com.example.demo.dto.request;

import com.example.demo.entity.Basket;
import com.example.demo.entity.BasketItem;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BasketAddRequest {
    private Long userId;
    private Long basketId;
}
