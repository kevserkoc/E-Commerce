package com.example.demo.dto.request;

import com.example.demo.entity.Basket;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserRequest {

    private String name;
    private String surname;
    private String email;
    private String address;
    private String password;
//    private Basket basket;

}
