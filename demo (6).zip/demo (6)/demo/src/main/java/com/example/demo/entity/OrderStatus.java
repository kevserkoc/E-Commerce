package com.example.demo.entity;

public enum OrderStatus {
    PAYMENT_APPROVED,
    PREPARING,
    IN_CARGO,
    COMPLETED

}
