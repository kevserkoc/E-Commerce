package com.example.demo.controller;

import com.example.demo.dto.request.BasketRequest;
import com.example.demo.dto.request.ProductRequest;
import com.example.demo.dto.response.BasketResponse;
import com.example.demo.dto.response.ProductResponse;
import com.example.demo.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RequestMapping("api/products")
@RequiredArgsConstructor
@RestController
public class ProductController {
    private final ProductService productService;

    @PostMapping
    ResponseEntity<ProductResponse> createProduct(@RequestBody ProductRequest request){
        ProductResponse product = productService.createProduct(request);
        return ResponseEntity.ok(product);
    }
    @GetMapping("search")
    public ResponseEntity<List<ProductResponse>> getByName(@RequestBody Map<String, String> request){
        String name = request.get("name");
        List<ProductResponse> productResponses = productService.searchProductsByName(name);
        return ResponseEntity.ok(productResponses);
    }

    @GetMapping("{categoryId}/product")
    public ResponseEntity<List<ProductResponse>> getProductsByCategoryId(@PathVariable Long categoryId){
        List<ProductResponse> productsByCategoryId = productService.getProductsByCategoryId(categoryId);
        return ResponseEntity.ok(productsByCategoryId);
    }
    @GetMapping
    public ResponseEntity<List<ProductResponse>> getAllProduct(){
        List<ProductResponse> allProducts = productService.getAllProducts();
        return ResponseEntity.ok(allProducts);
    }
}
