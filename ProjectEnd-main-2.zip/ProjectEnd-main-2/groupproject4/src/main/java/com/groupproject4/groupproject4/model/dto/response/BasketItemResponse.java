package com.groupproject4.groupproject4.model.dto.response;

import jakarta.persistence.criteria.CriteriaBuilder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BasketItemResponse {
    private Long id;
    private Integer quantity;
    private Long basketId;
    private Long productId;
}
