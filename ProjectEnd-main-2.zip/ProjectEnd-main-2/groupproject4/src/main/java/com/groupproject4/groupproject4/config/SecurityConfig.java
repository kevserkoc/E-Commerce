package com.groupproject4.groupproject4.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import com.groupproject4.groupproject4.service.UserInfoUserDetailsService;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    //Bir bean olarak userdetails 
    @Bean
    //authentication
    public UserDetailsService userDetailsService() {//burasını spring security sağlıyor.
        return new UserInfoUserDetailsService();//Burası kendi oluşturdğumuz service
    }//polimorfizm sayesinde implemente edilen sınıfı döndürebildik.

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http.csrf().disable()//springin sağla
        .authorizeHttpRequests()
        .requestMatchers("/auth/signup", "/auth/index").permitAll()
        //yukarıdaki pathlere kullanıcı girişi olmasın. login yapılmasa da bu pathlere giriş olmuyor.
        .and()
        .authorizeHttpRequests().requestMatchers("/auth/**")
        //create userımız herkese açık olmalı. yukarıdaki welcome, new haricinde diğer pathler için login kullanıcı girşi ister.
        .authenticated().and().formLogin().and().httpBasic().and().build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
        //encoder'ı decode de yapabilir.
    }

    //bean olarak tanımlayıp bu işi de springe bırakıyoruz.
    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authenticationProvider=new DaoAuthenticationProvider();
        authenticationProvider.setUserDetailsService(userDetailsService());
        authenticationProvider.setPasswordEncoder(passwordEncoder());
        return authenticationProvider;

    }
}
