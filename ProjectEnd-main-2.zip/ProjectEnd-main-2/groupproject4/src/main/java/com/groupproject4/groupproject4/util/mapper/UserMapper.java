package com.groupproject4.groupproject4.util.mapper;

import java.util.ArrayList;
import java.util.List;

import org.dozer.DozerBeanMapper;

import com.groupproject4.groupproject4.model.dto.request.UserInfoRequest;
import com.groupproject4.groupproject4.model.dto.request.UserRequest;
import com.groupproject4.groupproject4.model.entity.User;

public class UserMapper {
    private static DozerBeanMapper mapper = new DozerBeanMapper();
    public static void getMapper() {
        if(mapper == null)
        mapper = new DozerBeanMapper();
    }
    public static UserRequest mapUserToUserDto(User user){
        //mapper.map(var olan veri, dönüştürülmek istenen veri)
        //Dönüştürülmek istenen tek veri varsa bu metod kullanılır.
        //Bu kısımda entity olan Category sınıfından türetilen category mapper'a parametre olarak verildi.
        //Mapper'a diğer parametre olarak entitylerden dönüştürülmek istenen CategoryDto verilir. 
        UserRequest userDto = mapper.map( user, UserRequest.class);
        return userDto;
    }
    public static UserInfoRequest mapUserInfoToUserDto(User user){
        //mapper.map(var olan veri, dönüştürülmek istenen veri)
        //Dönüştürülmek istenen tek veri varsa bu metod kullanılır.
        //Bu kısımda entity olan Category sınıfından türetilen category mapper'a parametre olarak verildi.
        //Mapper'a diğer parametre olarak entitylerden dönüştürülmek istenen CategoryDto verilir. 
        UserInfoRequest userDto = mapper.map( user, UserInfoRequest.class);
        return userDto;
    }

    public static List<UserRequest> mapUserListToUserDtoList(List<User> userList){
        //Dönüştürülmek istenen birden fazla veri varsa liste döndüren bu metod kullanılır.
        List<UserRequest> returnList = new ArrayList<UserRequest>(); 
        for (User user : userList) {
            UserRequest userDto = mapUserToUserDto(user);
            returnList.add(userDto);
        }
        return returnList;
    }

    public static List<UserInfoRequest> mapUserInfoToUserDtoList(List<User> userList){
        //Dönüştürülmek istenen birden fazla veri varsa liste döndüren bu metod kullanılır.
        List<UserInfoRequest> returnList = new ArrayList<UserInfoRequest>(); 
        for (User user : userList) {
            UserInfoRequest userDto = mapUserInfoToUserDto(user);
            returnList.add(userDto);
        }
        return returnList;
    }

    public static User mapUserDtoToEntity(UserRequest userDto) {
        User user = mapper.map(userDto, User.class);
        return user;
    }
}
