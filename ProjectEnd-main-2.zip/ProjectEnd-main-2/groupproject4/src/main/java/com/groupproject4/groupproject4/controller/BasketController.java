package com.groupproject4.groupproject4.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.groupproject4.groupproject4.model.dto.request.BasketItemAddRequest;
import com.groupproject4.groupproject4.model.dto.request.BasketItemUpdateRequest;
import com.groupproject4.groupproject4.model.dto.request.BasketRequest;
import com.groupproject4.groupproject4.model.dto.request.ProductBasketRequest;
import com.groupproject4.groupproject4.model.dto.response.BasketResponse;
import com.groupproject4.groupproject4.model.entity.Basket;
import com.groupproject4.groupproject4.service.BasketService;

import lombok.RequiredArgsConstructor;

@RequestMapping("/auth/api/baskets")
@RequiredArgsConstructor
@RestController
public class BasketController {
    private final BasketService basketService;


    @GetMapping("/getBasket")
	@PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<BasketResponse> getBasket(@RequestParam("userId") Long userId) {
        BasketResponse basket = basketService.getBasketProducts(userId);
        return ResponseEntity.ok(basket);
    }

    @PostMapping("/createBasket")
	@PreAuthorize("hasAuthority('ROLE_USER')")
    ResponseEntity<BasketResponse> createBasket(@RequestBody BasketRequest request) {
        BasketResponse basket = basketService.createBasket(request);
        return ResponseEntity.ok(basket);
    }

    @PostMapping("/addBasketItem")
	@PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<BasketResponse> addBasketItem(@RequestBody BasketItemAddRequest request) {
        return ResponseEntity.ok(basketService.addProductToBasket(request));
    }

    @PutMapping("/updateBasketItem")
	@PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<BasketResponse> updateBasketItem(@RequestBody BasketItemUpdateRequest request) {
        return ResponseEntity.ok(basketService.updateBasketItem(request));
    }
}
