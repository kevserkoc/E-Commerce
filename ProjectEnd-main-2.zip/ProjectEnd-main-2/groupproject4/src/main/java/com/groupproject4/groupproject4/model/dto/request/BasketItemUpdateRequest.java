package com.groupproject4.groupproject4.model.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BasketItemUpdateRequest {
    private Integer quantity;
    private Long basketId;
    private Long basketItemId;
}
