package com.groupproject4.groupproject4.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.groupproject4.groupproject4.exception.category.CategoryNotFoundException;
import com.groupproject4.groupproject4.model.dto.request.CategoryRequest;
import com.groupproject4.groupproject4.model.dto.request.CategoryUpdateRequest;
import com.groupproject4.groupproject4.model.dto.response.CategoryResponse;
import com.groupproject4.groupproject4.model.entity.Category;
import com.groupproject4.groupproject4.repository.CategoryRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CategoryService {
    private final CategoryRepository categoryRepository;
    private final Logger logger = LoggerFactory.getLogger(CategoryService.class);
    public List<CategoryResponse> getAllCategories(){
        logger.info("Retrieved categories.");
        return categoryRepository.findAll()
                .stream()
                .map(this::getCategoryResponse)
                .toList();
    
    }
    public CategoryResponse createCategory(CategoryRequest request){
  
        Category build = Category.builder().name(request.getName()).build();
        Category savedCategory = categoryRepository.save(build); 
        logger.info("Created a new category with name: {}", request.getName());
        return getCategoryResponse(savedCategory);
    }
    public void deleteCategory(Long id){
        Category category = categoryRepository.findById(id).orElseThrow();
        category.setIsActive(false);
        categoryRepository.save(category);
        logger.info("Category deleted with id: {}", id);
    }
    public CategoryResponse updateCategory(CategoryUpdateRequest request){
        var optionalCategory = categoryRepository.findById(request.getId());
        if (optionalCategory.isPresent()){
            var category = optionalCategory.get();
            category.setName(request.getName());
            category = categoryRepository.save(category);
            logger.info("Category updated with id: {}", category.getId());
            return getCategoryResponse(category);
        }
        logger.error("Category update failed for id: {}", request.getId());
        throw new CategoryNotFoundException("Category not found for id: " + request.getId());

    }


    private CategoryResponse getCategoryResponse(Category savedCategory) {
        return CategoryResponse.builder()
                .id(savedCategory.getId())
                .name(savedCategory.getName())
                .build();
    }


    public Category getCategoryById(Long categoryId) {
        return categoryRepository.findById(categoryId)
        .orElseThrow(() -> new CategoryNotFoundException("Category not found for id: " + categoryId));
    }

    public Category getCategory(Long categoryId) {
        return categoryRepository.findById(categoryId).orElse(null);
    }
}
