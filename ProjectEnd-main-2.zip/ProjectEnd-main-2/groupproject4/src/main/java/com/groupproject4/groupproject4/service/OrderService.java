package com.groupproject4.groupproject4.service;

import java.time.LocalDateTime;
import java.util.ArrayList;

import com.groupproject4.groupproject4.model.dto.request.OrderRequest;
import com.groupproject4.groupproject4.model.dto.response.BasketResponse;
import com.groupproject4.groupproject4.model.dto.response.OrderResponse;
import com.groupproject4.groupproject4.model.dto.response.ProductResponse;
import com.groupproject4.groupproject4.model.entity.*;
import com.groupproject4.groupproject4.repository.BasketRepository;
import com.groupproject4.groupproject4.repository.OrderRepository;
import com.groupproject4.groupproject4.repository.ProductRepository;
import com.groupproject4.groupproject4.repository.UserRepository;

import java.util.ArrayList;
import java.util.List;

import com.groupproject4.groupproject4.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OrderService {
    private final OrderRepository orderRepository;
    private final UserService userService;
    private final BasketService basketService;



    public OrderResponse createOrder(OrderRequest orderRequest){
        Long userId = orderRequest.getUserId();
        User user = userService.getUserById(userId);


        Basket basket = user.getBasket();

//        basket.getBasketItems().clear();

        basketService.save(basket);
        userService.save(user);

        Order build = Order.builder().user(user).createdDate(LocalDateTime.now())
                .build();
        Order savedOrder = orderRepository.save(build);
        double v = (savedOrder.getUser().getBalance()) - (basketService.calculateTotalAmount(basket.getId()));
        user.setBalance(v);

        basket.setBasketItems(new ArrayList<>());
        basketService.save(basket);
        userService.save(user);

        return OrderResponse.builder()
              .availableBalance(v)
              .build();

    }



//    private BasketResponse mapToBasketResponse(Basket basket){
//        BasketResponse basketResponse = new BasketResponse();
//        basketResponse.setId(basket.getId());
//        basketResponse.setQuantity(basket.getQuantity());
//        basketResponse.setUserId(basket.getUser().getId());
//        basketResponse.setTotalAmount(basketService.calculateTotalAmount(basket.getId()));
//        basketResponse.setProductResponse(mapToProduct(basket.getProducts()));
//        return basketResponse;
//    }

    private List<ProductResponse> mapToProduct(List<Product> product){
        List<ProductResponse> productResponse = new ArrayList<>();
        for (Product product1 : product){
            ProductResponse productResponse1 = new ProductResponse();
            productResponse1.setCategoryId(product1.getId());
            productResponse1.setName(product1.getName());
            productResponse1.setStock(product1.getStock());
            productResponse1.setDescription(product1.getDescription());
            productResponse1.setImageUrl(product1.getImageUrl());
            productResponse.add(productResponse1);
        }
        return productResponse;
    }

    public List<OrderResponse> getAllOrders(Long userId) {

        List<Order> orders = orderRepository.findAll();
        User user = userService.getUserById(userId);
        return orders.stream().filter(x->x.getUser().getId().equals(user.getId()))
                .map(order ->OrderResponse.builder().availableBalance(user.getBalance())
                .build()).toList();
    }
}
