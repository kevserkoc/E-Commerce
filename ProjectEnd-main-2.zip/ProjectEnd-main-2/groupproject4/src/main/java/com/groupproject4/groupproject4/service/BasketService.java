package com.groupproject4.groupproject4.service;

import com.groupproject4.groupproject4.exception.NotFoundException;
import com.groupproject4.groupproject4.model.dto.request.*;
import com.groupproject4.groupproject4.model.dto.response.BasketItemResponse;
import com.groupproject4.groupproject4.model.dto.response.BasketResponse;
import com.groupproject4.groupproject4.model.dto.response.ProductResponse;
import com.groupproject4.groupproject4.model.entity.Basket;
import com.groupproject4.groupproject4.model.entity.BasketItem;
import com.groupproject4.groupproject4.model.entity.Product;
import com.groupproject4.groupproject4.model.entity.User;
import com.groupproject4.groupproject4.repository.BasketRepository;
import com.groupproject4.groupproject4.service.UserService;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BasketService {
    private final BasketRepository basketRepository;
    private final UserService userService;
    private final ProductService productService;
    private final BasketItemService basketItemService;


    @Transactional
    public BasketResponse createBasket(BasketRequest request) {
        User userById = userService.getUserById(request.getUserId());
        List<Long> basketItemIds = request.getBasketItemIds();
        List<BasketItem> basketItems = basketItemService.findAll(basketItemIds);


        Basket basket = Basket.builder()
                .user(userById)
                .basketItems(basketItems)
                .build();

        Basket savedBasket = basketRepository.save(basket);

        return getBasketResponse(savedBasket);

    }

    private BasketResponse getBasketResponse(Basket savedBasket) {
        List<BasketItemResponse> basketItemResponses = savedBasket.getBasketItems()
                .stream()
                .map(basketItemService::getBasketItemResponse)
                .toList();


        return BasketResponse.builder().id(savedBasket.getId())
                .userId(savedBasket.getUser().getId())
                .basketItemResponses(basketItemResponses)
                .totalAmount(calculateTotalAmount(savedBasket.getId()))
                .build();
    }

    public BasketResponse addProductToBasket(BasketItemAddRequest request) {

        Product product = productService.getProduct(request.getProductId());
        Optional<Basket> basket = basketRepository.findById(request.getBasketId());
        Integer quantity = request.getQuantity();

        BasketItem basketItem = BasketItem.builder().basket(basket.get())
                .product(product)
                .quantity(quantity)
                .build();

        BasketItem savedBasketItem = basketItemService.save(basketItem);
      //  basket.get().getBasketItems().add(savedBasketItem);

        return getBasketResponse(basket.get());

    }



    public BasketResponse updateBasketItem(BasketItemUpdateRequest request) {
        BasketItem basketItem = basketItemService.findById(request.getBasketItemId());
        Basket basket = getBasket(request.getBasketId());
        Integer quantity = request.getQuantity();

        int index = basket.getBasketItems().indexOf(basketItem);

        basketItem.setQuantity(quantity);
        BasketItem updatedBasketItem = basketItemService.save(basketItem);

        basket.getBasketItems().set(index, updatedBasketItem);

        return getBasketResponse(basket);

    }

    public BasketResponse getBasketProducts(Long userId) {

        User user = userService.getUserById(userId);
        Basket basket = basketRepository.findByUserId(user.getId());

        return getBasketResponse(basket);
    }


    public Double calculateTotalAmount(Long basketId) {
        Basket basket = basketRepository.findById(basketId).orElseThrow();

        return basket.getBasketItems().stream()
                .mapToDouble(basketItem -> basketItem.getProduct().getPrice() * basketItem.getQuantity())
                .sum();
    }


    public Basket getBasket(Long basketId) {
        return basketRepository.findById(basketId).orElseThrow(()->new NotFoundException("Not found"));
    }


    public void save(Basket basket) {
       basketRepository.save(basket);
    }
}
