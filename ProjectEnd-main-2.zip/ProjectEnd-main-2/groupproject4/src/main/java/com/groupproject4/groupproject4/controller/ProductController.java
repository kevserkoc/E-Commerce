package com.groupproject4.groupproject4.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.groupproject4.groupproject4.model.dto.request.ProductRequest;
import com.groupproject4.groupproject4.model.dto.response.ProductResponse;
import com.groupproject4.groupproject4.service.ProductService;

import lombok.RequiredArgsConstructor;

import lombok.RequiredArgsConstructor;

@RequestMapping("/auth/api/products")

@RequiredArgsConstructor
@RestController
public class ProductController {
    private final ProductService productService;

    @PostMapping
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    ResponseEntity<ProductResponse> createProduct(@RequestBody ProductRequest request){
        ProductResponse product = productService.createProduct(request);
        return ResponseEntity.ok(product);
    }
    @GetMapping("/search")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public ResponseEntity<List<ProductResponse>> getByName(@RequestBody Map<String, String> request){
        String name = request.get("name");
        List<ProductResponse> productResponses = productService.searchProductsByName(name);
        return ResponseEntity.ok(productResponses);
    }

    @GetMapping("/{categoryId}/product")
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public ResponseEntity<List<ProductResponse>> getProductsByCategoryId(@PathVariable Long categoryId){
        List<ProductResponse> productsByCategoryId = productService.getProductsByCategoryId(categoryId);
        return ResponseEntity.ok(productsByCategoryId);
    }
    @GetMapping
    @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public ResponseEntity<List<ProductResponse>> getAllProduct(){
        List<ProductResponse> allProducts = productService.getAllProducts();
        return ResponseEntity.ok(allProducts);
    }
}
