package com.groupproject4.groupproject4.model.entity;

public enum OrderStatus {
    PAYMENT_APPROVED,
    PREPARING,
    IN_CARGO,
    COMPLETED

}
