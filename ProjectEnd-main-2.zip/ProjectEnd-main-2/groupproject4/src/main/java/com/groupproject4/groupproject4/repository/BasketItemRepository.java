package com.groupproject4.groupproject4.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.groupproject4.groupproject4.model.entity.BasketItem;

@Repository
public interface BasketItemRepository extends JpaRepository<BasketItem, Long> {
    //    @Query("from BasketItem b where b.basket.id = :basketId")
//    List<BasketItem> findBasketItemsByBasketId(Long basketId);
}
