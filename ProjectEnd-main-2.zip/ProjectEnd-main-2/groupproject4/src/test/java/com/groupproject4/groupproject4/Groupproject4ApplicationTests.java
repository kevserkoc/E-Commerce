package com.groupproject4.groupproject4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Groupproject4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
