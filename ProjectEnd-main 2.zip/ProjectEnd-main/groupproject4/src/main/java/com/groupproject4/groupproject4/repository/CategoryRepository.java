package com.groupproject4.groupproject4.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.groupproject4.groupproject4.model.entity.Category;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoryRepository extends JpaRepository<Category,Long>{
    
}
