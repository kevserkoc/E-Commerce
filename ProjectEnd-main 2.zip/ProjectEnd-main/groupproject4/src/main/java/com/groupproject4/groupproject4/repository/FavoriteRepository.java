package com.groupproject4.groupproject4.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.groupproject4.groupproject4.model.entity.Favorite;
import com.groupproject4.groupproject4.model.entity.Product;
import com.groupproject4.groupproject4.model.entity.User;

@Repository
public interface FavoriteRepository extends JpaRepository<Favorite,Long>{
     boolean existsByUserAndProduct(User user, Product product);
     List<Favorite> findByUserId(Long userId);
}
