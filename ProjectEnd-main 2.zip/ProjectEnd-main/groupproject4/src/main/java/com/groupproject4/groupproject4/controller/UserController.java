package com.groupproject4.groupproject4.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.groupproject4.groupproject4.config.UserInfoUserDetails;
import com.groupproject4.groupproject4.exception.user.UserAlreadyTakenException;
import com.groupproject4.groupproject4.model.dto.request.UserInfoRequest;
import com.groupproject4.groupproject4.model.dto.request.UserRequest;
import com.groupproject4.groupproject4.model.dto.response.MessageResponse;
import com.groupproject4.groupproject4.model.entity.User;
import com.groupproject4.groupproject4.repository.UserRepository;
import com.groupproject4.groupproject4.service.UserService;

@RestController
@RequestMapping("/auth")
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    @Autowired
    UserService userService;

    @Autowired
    UserService serviceImpl;

    @Autowired
    UserRepository userRepository;

    @PostMapping(value = "/signup")
    public ResponseEntity<?> addUser(@RequestBody UserRequest user) {
        
        Long recordedId = userService.addUser(user);
        logger.info("User registered successfully.");
        return ResponseEntity.ok(new MessageResponse("User registered successfully! User id: " + recordedId));
    }

    @GetMapping(value = "/all")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String getAll() {
        return "admin";
    }

    @GetMapping(value = "/{id}/profile")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<?> profileUser(@PathVariable("id") int userId) {
        String authProfile = userService.getAuthProfile(userId);
        return ResponseEntity.ok(authProfile);
        
    }

    @PatchMapping(value = "/{id}/profile/update")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<?> updateProfile(@RequestBody User user) {
        return ResponseEntity.ok("User updated: " + userService.getUpdateProfile(user));
    }

    @PatchMapping(value = "/{id}/profile/changepassword")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<?> changePassword(@RequestBody User user) {
        return ResponseEntity.ok(userService.getChangePassword(user));
        
    }

    @GetMapping("/admin/userslist")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public List<UserInfoRequest> getAllUsers() {
        List<UserInfoRequest> userList = userService.getAllUsers();
        return userList;
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteUserById(@PathVariable Long id){
        userService.deleteUserById(id);
        return ResponseEntity.ok("User is deleted." + id);
    }

}
