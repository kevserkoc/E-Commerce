package com.groupproject4.groupproject4.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.groupproject4.groupproject4.model.dto.request.CategoryRequest;
import com.groupproject4.groupproject4.model.dto.request.CategoryUpdateRequest;
import com.groupproject4.groupproject4.model.dto.response.CategoryResponse;
import com.groupproject4.groupproject4.service.CategoryService;

import lombok.RequiredArgsConstructor;


@RestController
@RequestMapping("/auth/api/categories")

@RequiredArgsConstructor
public class CategoryController {
    private final CategoryService categoryService;

    @GetMapping
	@PreAuthorize("hasAuthority('ROLE_ADMIN') or hasAuthority('ROLE_USER')")
    ResponseEntity<List<CategoryResponse>> getAllProduct(){
        List<CategoryResponse> allCategories = categoryService.getAllCategories();
        return ResponseEntity.ok(allCategories);
    }
    @PostMapping
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
    ResponseEntity<CategoryResponse> createCategory(@RequestBody CategoryRequest request){
        CategoryResponse category = categoryService.createCategory(request);
      return ResponseEntity.ok(category);
    }
    @DeleteMapping("{id}")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<String> deleteCategory(@PathVariable Long id){
        categoryService.deleteCategory(id);
        return ResponseEntity.ok("Category is deleted." + id);
    }
    @PutMapping
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<CategoryResponse> updateCategory(@RequestBody CategoryUpdateRequest request) {
        return ResponseEntity.ok(categoryService.updateCategory(request));
    }
}
