package com.groupproject4.groupproject4.model.dto.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BasketRequest {
    private Long userId;
//    private List<Long> productIds;
    private List<Long> basketItemIds;
}
