package com.groupproject4.groupproject4.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.groupproject4.groupproject4.model.dto.request.ProductRequest;
import com.groupproject4.groupproject4.model.dto.response.ProductResponse;
import com.groupproject4.groupproject4.model.entity.Category;
import com.groupproject4.groupproject4.model.entity.Product;
import com.groupproject4.groupproject4.repository.ProductRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;
    private final CategoryService categoryService;
    private final Logger logger = LoggerFactory.getLogger(ProductService.class);

    public ProductResponse createProduct(ProductRequest request) {
        Product product = getProducts(request);
        Product savedProduct = productRepository.save(product);
        logger.info("Product created with id: {}", savedProduct.getId());
        return getProductResponse(product);
    }

    public List<ProductResponse> getAllProducts(){
        logger.info("Retrieved products.");
        return productRepository.findAll()
                .stream()
                .map(this::getProductResponse)
                .toList();
    }
    public List<ProductResponse> getProductsByCategoryId(Long categoryId){
        logger.info("Retrieved products for category id: {}", categoryId);
        Category category = categoryService.getCategoryById(categoryId); //exception
        if (category == null) {
            throw new RuntimeException("Category not found");
        }
        List<Product> products = productRepository.findAllByCategory_Id(category.getId());
        if (products.isEmpty()){
            throw new RuntimeException();
        }
        return  products.stream()
                .map(this::getProductResponse)
                .toList();
    }
public List<ProductResponse> searchProductsByName(String name){
    logger.info("Searching products by name: {}", name);
        List<Product> products = productRepository.findByNameWithQuery(name);
        if (products.isEmpty()){
            logger.warn("No products found with name: {}", name);
            throw new RuntimeException();
        }
        logger.info("Retrieved products for name: {}", name);
        return products.stream().map(this::getProductResponse)
                .toList();
}

    private  ProductResponse getProductResponse(Product product) {

        return ProductResponse.builder()
                .price(product.getPrice())
                .name(product.getName())
                .stock(product.getStock())
                .imageUrl(product.getImageUrl())
                .description(product.getDescription())
                .categoryId(product.getCategory().getId())
                .build();
    }

    private Product getProducts(ProductRequest request) {
        Category category = categoryService.getCategory(request.getCategoryId());
//        Category categoryById = categoryService.getCategoryById(request.getCategoryId());
       return Product.builder().name(request.getName())
                .price(request.getPrice())
                .description(request.getDescription())
                .imageUrl(request.getImageUrl())
                .category(category)
                .build();
    }

    public Product getProduct(Long productId) {

        return productRepository.findById(productId).orElseThrow();
    }

    public Optional<Product> findById(Long productId) {
       return productRepository.findById(productId);
    }

//    public List<Product> findAll(List<Product> products) {
//        return productRepository.findAll();
//    }
public List<Product> findAll(List<Long> productIds) {
    return productRepository.findAllById(productIds);

}


    public List<ProductResponse> getAllProductResponse(List<Product> products) {

        return products.stream().map(this::getProductResponse).toList();
    }

    public Product update(Product product) {
       return productRepository.save(product);
    }
}
