package com.groupproject4.groupproject4.service;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.groupproject4.groupproject4.config.UserInfoUserDetails;
import com.groupproject4.groupproject4.model.dto.request.FavoriteRequest;
import com.groupproject4.groupproject4.model.dto.response.FavoriteResponse;
import com.groupproject4.groupproject4.model.entity.Favorite;
import com.groupproject4.groupproject4.model.entity.Product;
import com.groupproject4.groupproject4.model.entity.User;
import com.groupproject4.groupproject4.repository.FavoriteRepository;
import com.groupproject4.groupproject4.repository.ProductRepository;
import com.groupproject4.groupproject4.repository.UserRepository;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
@Service
@RequiredArgsConstructor
public class FavoriteService {
    private final Logger logger = LoggerFactory.getLogger(FavoriteService.class);

    private final FavoriteRepository favoriteRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;
    @Autowired
    UserService serviceImpl;
    public FavoriteResponse createFavorite(FavoriteRequest request) {
         Authentication authentication = serviceImpl.getAuth();
        UserInfoUserDetails userDetails = (UserInfoUserDetails) authentication.getPrincipal();
         if(request.getUserId() == userDetails.getId()){  
        logger.info("Creating a new favorite for user: {} and product: {}", request.getUserId(), request.getProductId());
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new EntityNotFoundException("User not found with id: " + request.getUserId()));
        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new EntityNotFoundException("Product not found with id: " + request.getProductId()));
            if (favoriteRepository.existsByUserAndProduct(user, product)) {
                    logger.warn("User {} has already added product {} as a favorite.", user.getId(), product.getId());
                    throw new RuntimeException("Product is already in favorites.");
            }
        Favorite favorite = Favorite.builder()
                .user(user)
                .product(product)
                .build();

        Favorite savedFavorite = favoriteRepository.save(favorite);

        logger.info("Favorite created with id: {}", savedFavorite.getId());
       
        return FavoriteResponse.builder()
        .id(savedFavorite.getId())
        .userId(user.getId())
        .productId(product.getId())
        .productName(product.getName())
        .build();
    }
    else {
        logger.warn("Unauthorized attempt to create favorite for user: {}", request.getUserId());
        throw new RuntimeException("Unauthorized action.");
    }

       // return user.getName() +" isimli kullanıcı " + product.getName()  +" ürünü favoriye ekledi";
    }
//     public List<Long> getFavoriteProductIdsByUserId(Long userId) {
//         List<Favorite> userFavorites = favoriteRepository.findByUserId(userId);

//         return userFavorites.stream()
//                 .map(favorite -> favorite.getProduct().getId())
//                 .collect(Collectors.toList());
//     }

// public List<FavoriteResponse> getFavoriteProductNamesByUserId(Long userId) {
//         List<Favorite> userFavorites = favoriteRepository.findByUserId(userId);

//         return userFavorites.stream()
//                 .map(this::buildFavoriteResponse)
//                 .collect(Collectors.toList());
//     }
//     private FavoriteResponse buildFavoriteResponse(Favorite favorite) {
//         return FavoriteResponse.builder()
//                 .id(favorite.getId())
//                 .userId(favorite.getUser().getId())
//                 .productId(favorite.getProduct().getId())
//                 .productName(favorite.getProduct().getName())
//                 .build();
//     }
public List<String> getFavoriteProductNamesByUserId(Long userId) {
        Authentication authentication = serviceImpl.getAuth();
        UserInfoUserDetails userDetails = (UserInfoUserDetails) authentication.getPrincipal();
     if(userId == userDetails.getId()){     
        List<Favorite> userFavorites = favoriteRepository.findByUserId(userId);      
        return userFavorites.stream()
                .map(this::buildFavoriteResponse)
                .collect(Collectors.toList());
        }
        else {
            throw new RuntimeException("Error: Id you typed is not a valid id.");
        }
    }

    private String buildFavoriteResponse(Favorite favorite) {
        return favorite.getProduct().getName();
    }
}