package com.groupproject4.groupproject4.model.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.Where;


@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Where(clause = "is_active = true")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String username;
    // private String username;

    @Column(name = "email")
    private String email;

    // private String address;

    @Column(name = "password")
    private String password;

    @Builder.Default
    @Column(name = "is_active")
    private Boolean is_active = true;

    // @ManyToOne(fetch = FetchType.LAZY)
    // @JoinColumn(name = "role_id")
    // private Role role;

    // @Enumerated(EnumType.STRING)
    // @Column(length = 20)
    // private List<Role> role;

     private String role;

     @OneToOne(mappedBy = "user")
     private Basket basket;

     @Builder.Default
    private Double balance = 500.0;
  
}
