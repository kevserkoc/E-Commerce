package com.groupproject4.groupproject4.util.mapper;


public class UserProfileMapper {
    // private static DozerBeanMapper mapper = new DozerBeanMapper();
    // public static void getMapper() {
    //     if(mapper == null)
    //     mapper = new DozerBeanMapper();
    // }
    // public static UserProfileDto mapUserProfileToUserProfileDto(User user){
    //     //mapper.map(var olan veri, dönüştürülmek istenen veri)
    //     //Dönüştürülmek istenen tek veri varsa bu metod kullanılır.
    //     //Bu kısımda entity olan Category sınıfından türetilen category mapper'a parametre olarak verildi.
    //     //Mapper'a diğer parametre olarak entitylerden dönüştürülmek istenen CategoryDto verilir. 
    //     UserProfileDto userDto = mapper.map( user, UserProfileDto.class);
    //     return userDto;
    // }

    // public static List<UserProfileDto> mapUserProfileListToUserProfileDtoList(List<User> userList){
    //     //Dönüştürülmek istenen birden fazla veri varsa liste döndüren bu metod kullanılır.
    //     List<UserProfileDto> returnList = new ArrayList<UserProfileDto>(); 
    //     for (User user : userList) {
    //         UserProfileDto userDto = mapUserProfileToUserProfileDto(user);
    //         returnList.add(userDto);
    //     }
    //     return returnList;
    // }
}
