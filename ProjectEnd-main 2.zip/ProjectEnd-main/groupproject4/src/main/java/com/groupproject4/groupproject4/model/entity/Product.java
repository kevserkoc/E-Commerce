package com.groupproject4.groupproject4.model.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "products")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Builder.Default
    @Column(name = "stock")
    private Integer stock = 3;

    @Column(name = "description")
    private String description;

    @Column(name = "image_url")
    private String imageUrl;

    @Column(name = "price")
    private Double price;

//    private Integer quantity ;

    @ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL) //farklı
    @JoinColumn(name = "category_id")
    private Category category;

//
//    @ManyToMany(mappedBy = "products")
//    private List<Favorite> favoritedByUsers = new ArrayList<>();
//
//    @ManyToMany(mappedBy = "products")
//    @JsonIgnore
//    private List<Basket> baskets = new ArrayList<>();

}
