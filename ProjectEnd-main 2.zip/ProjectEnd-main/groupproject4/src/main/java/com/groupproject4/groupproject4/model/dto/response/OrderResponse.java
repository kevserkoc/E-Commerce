package com.groupproject4.groupproject4.model.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderResponse {
    @Builder.Default
    private String message = "Order is successfully.";

    private Double availableBalance;
}
