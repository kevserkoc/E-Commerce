package com.groupproject4.groupproject4.service;

import com.groupproject4.groupproject4.exception.NotFoundException;
import com.groupproject4.groupproject4.model.dto.request.BasketItemAddRequest;
import com.groupproject4.groupproject4.model.dto.response.BasketItemResponse;
import com.groupproject4.groupproject4.model.entity.Basket;
import com.groupproject4.groupproject4.model.entity.BasketItem;
import com.groupproject4.groupproject4.model.entity.Product;
import com.groupproject4.groupproject4.repository.BasketItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BasketItemService {
    private final BasketItemRepository basketItemRepository;


    public BasketItem findById(Long basketItemId) {
        return basketItemRepository.findById(basketItemId)
                .orElseThrow(()-> new NotFoundException("Not found"));
    }

    public BasketItem save(BasketItem basketItem) {

        return basketItemRepository.save(basketItem);
    }

    public BasketItemResponse getBasketItemResponse(BasketItem basketItem) {
        return BasketItemResponse.builder()
                .id(basketItem.getId())
                .basketId(basketItem.getBasket().getId())
                .quantity(basketItem.getQuantity())
                .productId(basketItem.getProduct().getId())
                .build();
    }

    public List<BasketItem> findAll(List<Long> basketItemIds) {
        return basketItemRepository.findAllById(basketItemIds);

    }
}
