package com.groupproject4.groupproject4.controller;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.groupproject4.groupproject4.model.dto.request.FavoriteRequest;
import com.groupproject4.groupproject4.model.dto.response.FavoriteResponse;
import com.groupproject4.groupproject4.service.FavoriteService;

import java.util.List;
import java.util.Map;
@RestController
@RequestMapping("/auth/api/favorites")
@RequiredArgsConstructor
public class FavoriteController {
      private final FavoriteService favoriteService;

 @PostMapping
 @PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public ResponseEntity<FavoriteResponse> createFavorite(@RequestBody FavoriteRequest request) {
       
            FavoriteResponse response = favoriteService.createFavorite(request);          
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
   
}
 
@GetMapping("/{userId}")
@PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
    public ResponseEntity<List<String>> getFavoriteProductNamesByUserId(@PathVariable Long userId) {
        List<String> favoriteProductNames = favoriteService.getFavoriteProductNamesByUserId(userId);
        return new ResponseEntity<>(favoriteProductNames, HttpStatus.OK);
    }

}
