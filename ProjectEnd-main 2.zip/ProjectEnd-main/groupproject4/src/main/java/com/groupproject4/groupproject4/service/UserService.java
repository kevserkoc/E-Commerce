package com.groupproject4.groupproject4.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.groupproject4.groupproject4.config.UserInfoUserDetails;
import com.groupproject4.groupproject4.exception.user.UserAlreadyTakenException;
import com.groupproject4.groupproject4.exception.user.UserNotFoundException;
import com.groupproject4.groupproject4.model.dto.request.UserInfoRequest;
import com.groupproject4.groupproject4.model.dto.request.UserRequest;
import com.groupproject4.groupproject4.model.dto.response.UserResponse;
import com.groupproject4.groupproject4.model.entity.Basket;
import com.groupproject4.groupproject4.model.entity.User;
import com.groupproject4.groupproject4.repository.UserRepository;
import com.groupproject4.groupproject4.util.mapper.UserMapper;

@Service
public class UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    UserRepository userRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    private ModelMapper modelMapper;

    public Long addUser(UserRequest userInfo) {
        userInfo.setPassword(passwordEncoder.encode(userInfo.getPassword()));
        if (userRepository.existsByUsername(userInfo.getUsername())) {
            throw new UserAlreadyTakenException("Error: Username is already in use!");
          }
      
          if (userRepository.existsByEmail(userInfo.getEmail())) {
            throw new UserAlreadyTakenException("Error: Email is already in use!");
          }
        User user = modelMapper.map(userInfo, User.class);
        user = userRepository.save(user);
        UserResponse result = modelMapper.map(user, UserResponse.class);
        return result.getId();
    }

    public Authentication getAuth() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth;
    }
    
    public List<UserInfoRequest> getAllUsers() {
        List<User> userList = userRepository.getAllUsers();// findall ile aynı. bu entity listesi dönüyor.
        List<UserInfoRequest> resultList = UserMapper.mapUserInfoToUserDtoList(userList);
        return resultList;
    }

    public String changePassword(User user, Long id) {
        User persistedUser = getUserById(id);
		if(persistedUser == null){
			throw new UserNotFoundException("User "+user.getId()+" doesn't exist");
		}
        persistedUser.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(persistedUser);
		return "Password was changed.";
    }

    public User updateProfile(User user, Long id) {
        User persistedUser = getUserById(id);
		if(persistedUser == null){
			throw new UserNotFoundException("User "+user.getId()+" doesn't exist");
		}
		persistedUser.setUsername(user.getUsername());
		persistedUser.setEmail(user.getEmail());
		//persistedUser.setRole(user.getRole());
		return userRepository.save(persistedUser);
    }

    public User getUserById(Long id) {
        Optional<User> optionalUser = userRepository.findById(id);
        
        // Eğer değer varsa, Category nesnesini döndürür.
        if (optionalUser.isPresent()) {
            logger.info("User is found.");
            return optionalUser.get();
        } else {
            // Değer bulunamadıysa, gerekli işlemleri yapabilir veya null dönebilirsiniz.
            logger.info("User is not found.");
            throw new UserNotFoundException("Error: User is not found.");
        }
    }

    public String deleteUserById(Long id) {
        User user = userRepository.findById(id).orElseThrow();
        user.setIs_active(false);
        userRepository.save(user);
        //logger.info("Category deleted with id: {}", id);
        logger.info("User" + user.getId() + "is deleted");
        return "User is deleted";
    }

    public String getAuthProfile(int userId) {
        Authentication authentication = getAuth();
        UserInfoUserDetails userDetails = (UserInfoUserDetails) authentication.getPrincipal();
        if(userId == userDetails.getId()){
            logger.info("User profile viewed.");
            return ("id: " + userDetails.getId() + "\n" +
                "name: " + userDetails.getUsername() + "\n" +
                "email: " + userDetails.getEmail() + "\n" +
                "role: " + userDetails.getAuthorities()
        );
        }
        else {
            throw new RuntimeException("Error: You wrote the id is not a valid id.");
        }
    }

    public String getUpdateProfile(User user) {
        Authentication authentication = getAuth();
        UserInfoUserDetails userDetails = (UserInfoUserDetails) authentication.getPrincipal();
        User updateProfile = updateProfile(user, userDetails.getId());
        logger.info("User is updated");
        return ("name: " + updateProfile.getUsername() + "\n" +
                "email: " + updateProfile.getEmail() + "\n" +
                "role: " + updateProfile.getRole());
    }

    public String getChangePassword(User user){
        Authentication authentication = getAuth();
        UserInfoUserDetails userDetails = (UserInfoUserDetails) authentication.getPrincipal();
        String changePassword = changePassword(user, userDetails.getId());
        logger.info("User:" + user.getId() + "change password");
        return (changePassword);
    }
    public void save(User basket) {
       userRepository.save(basket);
    }

}
