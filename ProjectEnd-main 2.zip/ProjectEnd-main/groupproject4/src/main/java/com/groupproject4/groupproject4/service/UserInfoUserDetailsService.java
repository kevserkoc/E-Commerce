package com.groupproject4.groupproject4.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.groupproject4.groupproject4.config.UserInfoUserDetails;
import com.groupproject4.groupproject4.model.entity.User;
import com.groupproject4.groupproject4.repository.UserRepository;

@Component
public class UserInfoUserDetailsService implements UserDetailsService{
    @Autowired
    private UserRepository repository;

    //Database'den gelen sınıf null değilse oluşturduğum sınıfa maple. null ise hata fırlat.
    //Optional null olabilir. Null olma ihtimali olan nesnelerde optional kullanılır.
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //repositor'de tanımladığım findByName ile database'den ismi çekiyoruz.
        //Bu nesne varsa tipini döndür yoksa kullanıcı bulunamadı hatası döndür.
        Optional<User> userInfo = repository.findByUsername(username);
        return userInfo.map(UserInfoUserDetails::new).orElseThrow(() -> new UsernameNotFoundException("User not found" + username));
    }
}
