package com.groupproject4.groupproject4.model.dto;

import com.groupproject4.groupproject4.model.dto.request.UserRequest;

import lombok.Data;

@Data
public class ChangePasswordDto extends UserRequest{
    private String password;
    private String passwordRepeat;
    private String email;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}
