package com.groupproject4.groupproject4.exception.user;

public class UserAlreadyTakenException extends RuntimeException{
    public UserAlreadyTakenException() {
        super();
    }
    public UserAlreadyTakenException(String message) {
        super(message);
    }
    public UserAlreadyTakenException(Throwable cause) {
        super(cause);
    }
    public UserAlreadyTakenException(String message, Throwable cause) {
        super(message, cause);
    }
}
